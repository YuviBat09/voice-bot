from flask import Blueprint, render_template
from .models import create_recipes

recipes_bp = Blueprint("recipes", __name__)
all_recipes = create_recipes()

@recipes_bp.route("/browse")
def browse():
    return render_template("browse.html", recipes=all_recipes)

@recipes_bp.route("/<int:recipe_id>")
def recipe_detail(recipe_id):
    recipe = all_recipes[recipe_id]
    return render_template("recipe_detail.html", recipe=recipe)
